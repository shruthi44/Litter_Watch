package com.example.major.project;

public enum ComplaintCatogery {
    ENVIRONMENT,
    ROADSAFETY,
    FOOD,
    HEALTH

}
