package com.aw.complaint.system.business;

public enum Status {
    SUBMITTED,
    IN_PROGRESS,
    COMPLETED
}
