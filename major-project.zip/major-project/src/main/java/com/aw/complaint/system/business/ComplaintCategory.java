package com.aw.complaint.system.business;

public enum ComplaintCategory {
    ENVIRONMENT,
    ROAD_SAFETY,
    FOOD,
    HEALTH

}
